import socket
import pyaudio
import select
import threading

... Do somthing

